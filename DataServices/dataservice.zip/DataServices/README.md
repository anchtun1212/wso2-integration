# Test the Services

By Default the result in XML: add this in `Headers`: `Accept=application/json`

Run: `http://localhost:8290/services/RDBMSDataService.HTTPEndpoint/employee`

Run: `http://localhost:8290/services/RDBMSDataService.HTTPEndpoint/employee/1`

