# Link: Create App Passwords To Use Gmail account For Less Secure Apps | New Version Generate App Password

This link is important how to generate a new password that will be used instaed of your original password.

https://www.youtube.com/watch?v=nuD6qNAurVM

